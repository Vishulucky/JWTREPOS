package com.sessionloginviewretrofit.presenter;

/**
 * Created by lenovo on 3/31/2018.
 */

public interface Presenter {
    void logInRetro();
}
