package test.tuto_passport.entities;

import java.util.List;

public class PostResponse {

    List<Post> data;

    public List<Post> getData() {
        return data;
    }
}
